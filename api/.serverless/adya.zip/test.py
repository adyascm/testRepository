from flask import Flask

print("test")
app = Flask(__name__)
print(app)