def login(email, name, pwd):
    return {"email":"amit"}